#! /bin/sh
./nc_test -c
