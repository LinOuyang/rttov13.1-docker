Optical depth coefficients for RTTOV v13 predictors on 54L.

MW sensors, VIS/IR sensors, hyperspectral IR sounders.

v13 predictors support all combinations of variable gases. Variable gases supported are indicated in the filename (see the user guide and coefficients download page for more information).
Coefficients are trained for zenith angles up to 85 degrees (for solar-affected channels and all channels on GEO sensors).
Solar radiation is supported.

"_ironly" files contain only the thermal IR channels for VIS/IR sensors. These can be used directly in place of the old v7/v8 predictor coefficients.