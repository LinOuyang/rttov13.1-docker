:mod:`pyrttov.decorator` --- Decorators used by pyrttov (internal)
==================================================================

.. automodule:: pyrttov.decorator
   :synopsis: Decorators used by pyrttov (internal)

.. versionadded:: 11.3

Functions
---------

.. autofunction:: property_ro
.. autofunction:: lock_attributes
.. autofunction:: add_descriptors_opts
.. autofunction:: add_descriptors_gases2D
.. autofunction:: add_descriptors_gasesK
