:mod:`pyrttov.option` --- Define a class to handle RTTOV options
================================================================

.. automodule:: pyrttov.option
   :synopsis: Define a class to handle RTTOV options

.. versionadded:: 11.3

Classes
-------

.. autoclass:: Options
   :show-inheritance:
   :members:
   :member-order: alphabetical

