:mod:`pyrttov.profilescatt` --- Define classes to handle vertical profiles for RTTOV-SCATT
==========================================================================================

.. automodule:: pyrttov.profilescatt
   :synopsis: Define classes to handle vertical profiles for RTTOV-SCATT

.. versionadded:: 12.1

Classes
-------
   
.. autoclass:: ProfilesScatt
   :show-inheritance:
   :members:
   :member-order: alphabetical

