.. PyRTTOV documentation master file, created by
   sphinx-quickstart on Wed Dec 23 11:48:51 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to PyRTTOV's documentation!
===================================

Contents:

.. toctree::
   :maxdepth: 2

   The PyRTTOV wrapper public API <library/pyrttov_public>


   The PyRTTOV standard Library <library/index>


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

