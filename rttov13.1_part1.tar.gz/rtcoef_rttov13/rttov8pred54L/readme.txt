Optical depth coefficients for RTTOV v8 predictors on 54L.

IR sensors (excluding hyperspectral IR sounders).

v8 predictors support variable O3 and CO2.
Coefficients are trained only for zenith angles up to 65 degrees.
Solar radiation is not supported, only thermal IR channels included.

Consider using v13 predictor coefficients instead.