Coefficients for the PC-RTTOV Principal Components based model. 

Filenames contain text indicating the options supported (see the user guide or coefficients download web page for more information).

PC-RTTOV coefficients must be used with the rtcoef file used in the training. These are indicated by "pcrttov_compat" in the filename (see the coefficients download web page).