#!/usr/bin/env python

# ------------------------------------------------------------------------------
# Defines a function that returns the channel number in the specified mviri-vis
# RTTOV rtcoef coefficient file corresponding to the SRF valid at the date
# closest to the specified date.
# ------------------------------------------------------------------------------

from datetime import date

# ---------------------------------------------------------------------------------------
# | Satellite  | Number of SRFs/channels | Date of first channel | Date of last channel |
# ---------------------------------------------------------------------------------------
# | Meteosat-2 |           78            |      1982   078       |      1991   303      |
# | Meteosat-3 |           20            |      1988   348       |      1991   123      |
# | Meteosat-4 |           37            |      1989   213       |      1994   033      |
# | Meteosat-5 |          126            |      1991   123       |      2006   348      |
# | Meteosat-6 |           11            |      1997   033       |      1998   123      |
# | Meteosat-7 |          157            |      1997   258       |      2017   078      |
# ---------------------------------------------------------------------------------------

# Data for each platform
year_first_list   = [1982, 1988, 1989, 1991, 1997, 1997]
day_first_list    = [  78,  348,  213,  123,   33,  258]
year_last_list    = [1991, 1991, 1994, 2006, 1998, 2017]
day_last_list     = [ 303,  123,   33,  348,  123,   78]
nchannels         = [  78,   20,   37,  126,   11,  157]

# SRFs sampled on these days of each year and at the given interval
first_day_in_year = 33
last_day_in_year  = 348
delta_days        = 45

# List of days on which SRFs were sampled
sampled_day_list    = list(range(first_day_in_year, last_day_in_year + 1, delta_days))

# Boundaries to determine which channel/SRF should be used for a given day of year
# Require a special case for the first/last interval crossing year boundary
first_day_boundary  = first_day_in_year - (first_day_in_year + 365 - last_day_in_year) // 2
second_day_boundary = first_day_in_year + delta_days // 2
last_day_boundary   = last_day_in_year - delta_days // 2
day_boundaries      = [first_day_boundary, ] + list(range(second_day_boundary, last_day_boundary + 1, delta_days))


def mviri_vis_channel_select(platform, year, month, day):
    """Return the RTTOV rtcoef file channel number for the given Meteosat
       platform (2-7) for the SRF closest in time to the given date"""

    # Get the parameters for this platform   
    isat = platform - 2
    year_first = year_first_list[isat]
    day_first  = day_first_list[isat]
    year_last  = year_last_list[isat]
    day_last   = day_last_list[isat]
    nchan      = nchannels[isat]

    # Quick exit if year is out of range
    if year < year_first:
        return 1
    if year > year_last:
        return nchan
    
    # Calculate day of year
    day = date(year, month, day).timetuple().tm_yday # day of year

    # Quick exit if we are beyond the first/last day bounds
    if year == year_first and day <= day_first:
        return 1
    if year == year_last and day >= day_last:
        return nchan

    # Count through sampled SRFs to the one we want
    chan = 0
    
    # Loop from first year to the specified year
    for y in range(year_first, year + 1):

        # Loop over the days on which SRFs were sampled
        for i, d in enumerate(sampled_day_list):

            # Within these loops we increment chan for each _valid_ day boundary
            # that is greater than the specified date

            # Valid day boundaries are those after day_first in year_first,
            # all day boundaries in years after year_first and before the specified year,
            # and day boundaries smaller than calculated day of year in the specified year:
            if y > year_first or d >= day_first:
                if y < year or day > day_boundaries[i]:
                    chan += 1

    return chan


if __name__ == '__main__':
    platform = 2
    assert(mviri_vis_channel_select(platform, 1982,  4, 1) == 1)
    assert(mviri_vis_channel_select(platform, 1991, 10, 27) == nchannels[platform-2])

    platform = 3
    assert(mviri_vis_channel_select(platform, 1989,  1,  8) == 1)
    assert(mviri_vis_channel_select(platform, 1989,  1,  9) == 2)
    assert(mviri_vis_channel_select(platform, 1991,  4, 27) == nchannels[platform-2])