Optical depth coefficients for RTTOV v9 predictors on 54L.

VIS/IR sensors (excluding hyperspectral IR sounders).

These v9 predictors support variable O3 and CO2 for most VIS/IR sensors, but some are O3-only.
Coefficients are trained for zenith angles up to 85 degrees (for solar-affected channels and all channels on GEO sensors).
Solar radiation is supported.

Consider using v13 predictor coefficients instead.