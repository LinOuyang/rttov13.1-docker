Optical depth coefficients for RTTOV v8 predictors on 51L.

SSU only, including the "PMC shift" files which account for change in instrument CO2 cell pressure.

v8 predictors support variable O3 and CO2.
Coefficients are trained only for zenith angles up to 65 degrees.
