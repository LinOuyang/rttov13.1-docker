Optical depth coefficients for RTTOV v9 predictors on 101L.

Primarily hyperspectral IR sounders.

These v9 predictors support all variable gases implemented in RTTOV.
Coefficients are trained for zenith angles up to 85 degrees (for solar-affected channels and all channels on GEO sensors).
Solar radiation is supported.

Consider using v13 predictor coefficients instead.