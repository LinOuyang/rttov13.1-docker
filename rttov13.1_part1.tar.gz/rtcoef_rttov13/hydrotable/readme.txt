Optical property files for RTTOV-SCATT (the MW scattering model). 

The NWP SAF hydrotables contain properties for 5 particle types: rain, snow, graupel, cloud liquid water, cloud ice water (in that order). See user guide and coefficients download page for more information.