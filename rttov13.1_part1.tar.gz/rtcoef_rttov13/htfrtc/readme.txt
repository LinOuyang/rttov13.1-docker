Coefficient files for the HTFRTC Principal Components based model implemented within RTTOV. 

For all simulations the "static" file is required, along with the file specific to the sensor being simulated. Files are available in ASCII or netCDF format, but cannot be converted between formats.

When running HTFRTC simulations you do not need to supply an rtcoef RTTOV optical depth coefficient file.