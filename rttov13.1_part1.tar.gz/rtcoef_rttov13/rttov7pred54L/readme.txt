Optical depth coefficients for RTTOV v7 predictors on 54L.

MW sensors, IR sensors, hyperspectral IR sounders.

v7 predictors support variable O3 (for IR sensors).
Coefficients are trained only for zenith angles up to 65 degrees.
Solar radiation is not supported, only thermal IR channels included.

Consider using v13 predictor coefficients instead.